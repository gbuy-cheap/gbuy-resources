/**
 * Basis variable for helper functions
 * @type {{}}
 */
var Helper = function () {

};
