const MESSAGE_TARGET = {
    BACKGROUND: "background",
    CONTENT: "content",
    POPUP: "popup"
};
