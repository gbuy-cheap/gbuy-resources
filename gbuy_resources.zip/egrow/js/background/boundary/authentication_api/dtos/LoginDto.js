class LoginDto {
    token_type;
    expires_in;
    access_token;
    refresh_token;
}
