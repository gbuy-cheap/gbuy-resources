const API_MODULE_TYPE = Object.freeze({
    CE: "CE",
    APP: "APP",
    AUTH: "AUTH"
});
