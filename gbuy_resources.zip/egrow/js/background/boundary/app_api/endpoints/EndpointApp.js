class EndpointApp extends AbstractEndpoint {
    constructor(appApi, endpointPath, isDevMode) {
        super(appApi, endpointPath, true, isDevMode);
    }
}
