/**
 * It holds the content components in {@link ContentStart} and is required to
 * reference the components asynchronously.
 */
CONTENT = function () {

};
