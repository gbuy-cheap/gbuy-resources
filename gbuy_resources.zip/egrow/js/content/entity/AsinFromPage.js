class AsinFromPage {

    constructor(asin, isSponsored, position, href) {
        this.asin = asin;
        this.isSponsored = isSponsored;
        this.position = position;
        this.href = href;
    }
}
