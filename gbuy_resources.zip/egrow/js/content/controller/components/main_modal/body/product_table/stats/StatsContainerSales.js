class StatsContainerSales extends StatsContainer {
    constructor () {
        super(".sales-stats");
    }
}
