class StatsContainerReviews extends StatsContainer {
    constructor () {
        super(".reviews-stats");
    }
}
