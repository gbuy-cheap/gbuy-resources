class StatsContainerPrice extends StatsContainer {
    constructor () {
        super(".price-stats", 2);
    }
}
