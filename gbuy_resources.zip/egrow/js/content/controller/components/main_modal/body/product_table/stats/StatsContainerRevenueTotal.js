class StatsContainerRevenueTotal extends StatsContainer {
    constructor () {
        super(".revenue-total-stats");
    }
}
