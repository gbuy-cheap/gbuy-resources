class StatsContainerBsr extends StatsContainer {
    constructor () {
        super(".bsr-stats");
    }
}
