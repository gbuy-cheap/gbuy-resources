class StatsContainerRevenue extends StatsContainer {
    constructor () {
        super(".revenue-stats");
    }
}
