class LimitationModalProductTracker extends LimitationModal {
    constructor () {
        super("#limitModalProductTracker", "#limitProductTrackerUpgradeButton");
    }
}
