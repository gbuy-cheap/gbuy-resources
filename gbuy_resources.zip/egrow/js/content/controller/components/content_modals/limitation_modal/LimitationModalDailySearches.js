class LimitationModalDailySearches extends LimitationModal {
    constructor () {
        super("#limitModalDailySearches", "#limitDailySearchesUpgradeButton");
    }
}
